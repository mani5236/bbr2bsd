/*
 * bbr2_os.h - OS portability layer for the BBRv2 core.
 *
 * The core (src/bbr2.c, src/bbr2_rate.c) is written against only this file.
 * It builds unchanged as
 *   - a FreeBSD / BSD kernel module        (-D_KERNEL)
 *   - a userland library / simulator       (hosted C, <stdint.h>)
 *
 * If your customized stack uses different integer typedefs or assertion
 * macros, this is the ONLY file you need to touch.
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#ifndef BBR2_OS_H
#define BBR2_OS_H

#ifdef _KERNEL
#include <sys/param.h>
#include <sys/systm.h>
#include <sys/types.h>
#define BBR2_ASSERT(x)	KASSERT((x), ("bbr2: assertion failed: %s", #x))
#else
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>
#define BBR2_ASSERT(x)	assert(x)
#endif

#define BBR2_MIN(a, b)	((a) < (b) ? (a) : (b))
#define BBR2_MAX(a, b)	((a) > (b) ? (a) : (b))

#define BBR2_ZERO(p, n)		memset((p), 0, (n))
/* memset() is available in the FreeBSD kernel via <sys/systm.h>. */

#endif /* BBR2_OS_H */
