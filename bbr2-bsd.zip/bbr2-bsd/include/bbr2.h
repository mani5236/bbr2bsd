/*
 * bbr2.h - BBR v2 congestion control core: public API and state.
 *
 * Units used everywhere in this library
 *   time        : microseconds, uint64_t monotonic clock (never wraps in practice)
 *   RTT         : microseconds
 *   sizes       : bytes
 *   rates       : bytes per second
 *   sequence    : 32-bit TCP sequence numbers, wrap-safe comparisons
 *   gains       : fixed point, BBR2_UNIT (256) == 1.0
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#ifndef BBR2_H
#define BBR2_H

#include "bbr2_os.h"

#define BBR2_VERSION		"1.0.0"
#define BBR2_SCALE		8
#define BBR2_UNIT		(1u << BBR2_SCALE)

/* Number of in-flight send records kept per connection (power of two).
 * Memory per connection ~= BBR2_TXRING_SZ * 64 bytes. */
#ifndef BBR2_TXRING_SZ
#define BBR2_TXRING_SZ		256
#endif

#define BBR2_INF32		0xFFFFFFFFu
#define BBR2_INF64		(~(uint64_t)0)

enum bbr2_mode {
	BBR2_STARTUP = 0,
	BBR2_DRAIN,
	BBR2_PROBE_BW,
	BBR2_PROBE_RTT
};

/* Sub-states of PROBE_BW. */
enum bbr2_phase {
	BBR2_PHASE_DOWN = 0,	/* drain queue created by the previous probe */
	BBR2_PHASE_CRUISE,	/* steady state, leaves headroom below inflight_hi */
	BBR2_PHASE_REFILL,	/* one round at gain 1.0 to refill the pipe */
	BBR2_PHASE_UP		/* probe for more bandwidth (gain 1.25) */
};

/* Congestion-avoidance state reported by the stack with every ACK. */
enum bbr2_ca_state {
	BBR2_CA_OPEN = 0,
	BBR2_CA_RECOVERY,	/* fast recovery / SACK recovery */
	BBR2_CA_LOSS		/* after retransmission timeout */
};

/* ------------------------------------------------------------------ */
/* Tunables.  bbr2_params_default() fills in the values from the BBRv2 */
/* reference design; every connection owns a private copy so a sysctl  */
/* layer can override them per-connection or globally.                 */
/* ------------------------------------------------------------------ */
struct bbr2_params {
	uint32_t high_gain;		/* STARTUP pacing gain, 2/ln2 = 739 */
	uint32_t drain_gain;		/* DRAIN pacing gain, 1/high_gain = 88 */
	uint32_t startup_cwnd_gain;	/* cwnd gain in STARTUP/DRAIN (512 = 2.0) */
	uint32_t cwnd_gain;		/* cwnd gain in PROBE_BW (512 = 2.0) */
	uint32_t probe_up_gain;		/* 320 = 1.25 */
	uint32_t probe_down_gain;	/* 192 = 0.75 */
	uint32_t beta;			/* multiplicative decrease, 179 = 0.7 */
	uint32_t loss_thresh_ppt;	/* loss rate (per mille) that ends a probe: 20 = 2% */
	uint32_t ecn_thresh;		/* CE fraction (/256) that ends a probe: 128 = 50% */
	uint32_t ecn_factor;		/* inflight_lo cut = factor*alpha (/256): 85 = 1/3 */
	uint32_t ecn_alpha_gain_shift;	/* alpha EWMA gain = 1/2^shift, 4 = 1/16 */
	uint32_t ecn_alpha_init;	/* initial alpha (/256) */
	uint32_t headroom_pct;		/* slack below inflight_hi while cruising: 15 */
	uint32_t full_bw_thresh;	/* STARTUP plateau threshold, 320 = 1.25x */
	uint32_t full_bw_cnt;		/* rounds without growth => pipe full: 3 */
	uint32_t full_loss_cnt;		/* loss events/round that can end STARTUP: 6 */
	uint32_t pacing_margin_pct;	/* pace slightly under bw estimate: 1 */
	uint32_t min_rtt_win_ms;	/* long-term min RTT window: 10000 */
	uint32_t probe_rtt_win_ms;	/* how often to probe RTT: 5000 */
	uint32_t probe_rtt_dur_ms;	/* time spent in PROBE_RTT: 200 */
	uint32_t probe_rtt_cwnd_gain;	/* 128 = 0.5 * BDP */
	uint32_t probe_wait_base_ms;	/* min time between bw probes: 2000 */
	uint32_t probe_wait_rand_ms;	/* + random 0..this: 1000 */
	uint32_t probe_rand_rounds;	/* initial random round offset: 2 */
	uint32_t probe_max_rounds;	/* cap for Reno-coexistence wait: 63 */
	uint32_t probe_reno_gain;	/* 256 = probe every BDP-in-packets rounds */
	uint32_t probe_up_max_rounds;	/* exponential growth cap: 30 */
	uint32_t extra_acked_gain;	/* ack aggregation gain, 256 = 1.0 (0 disables) */
	uint32_t extra_acked_win_rtts;	/* window for extra_acked filter: 5 */
	uint32_t min_cwnd_segs;		/* 4 */
	uint32_t init_cwnd_segs;	/* 10 */
	uint32_t max_quantum;		/* max send burst the pacer should allow: 65536 */
};

/* One record per transmitted chunk; used by the delivery-rate sampler. */
struct bbr2_txrec {
	uint64_t sent_us;		/* time this chunk was sent */
	uint64_t delivered;		/* b->delivered when sent */
	uint64_t delivered_us;		/* b->delivered_us when sent */
	uint64_t first_tx_us;		/* b->first_tx_us when sent */
	uint32_t start_seq;
	uint32_t end_seq;		/* start_seq + len */
	uint32_t in_flight;		/* bytes in flight including this chunk */
	uint32_t lost;			/* b->lost_total when sent */
	uint32_t ce;			/* b->ce_total when sent */
	uint8_t  app_limited;
	uint8_t  is_retrans;
	uint8_t  acked;			/* already counted via SACK */
	uint8_t  pad;
};

/* Input to bbr2_on_ack(): everything the stack knows after processing one ACK. */
struct bbr2_ack {
	uint64_t now_us;
	uint32_t ack_seq;	/* snd_una after this ACK */
	uint32_t acked_bytes;	/* newly cumulatively ACKed + newly SACKed bytes */
	uint32_t lost_bytes;	/* bytes newly marked lost since previous call */
	uint32_t ce_bytes;	/* subset of acked_bytes that saw ECN-CE feedback */
	int64_t  rtt_us;	/* RTT sample for this ACK, or -1 if none */
	uint32_t inflight;	/* bytes in flight AFTER this ACK */
	int      ca_state;	/* enum bbr2_ca_state */
};

/* Internal per-ACK rate sample (exposed for tests). */
struct bbr2_rs {
	int      have_prior;	/* a send record was matched (round tracking) */
	int      valid;		/* a usable delivery-rate sample was produced */
	uint64_t bw;		/* bytes/s */
	uint64_t delivered;	/* bytes delivered over the sample interval */
	uint64_t interval_us;
	uint64_t prior_delivered;
	uint32_t tx_in_flight;	/* in-flight when the sampled chunk was sent */
	uint32_t lost_interval;	/* bytes lost since the sampled chunk was sent */
	uint32_t ce_interval;	/* CE-marked bytes since the sampled chunk was sent */
	uint32_t acked;
	uint32_t lost;
	uint32_t ce;
	uint32_t inflight;
	int      is_app_limited;
};

/* Read-only snapshot for sysctl / debugging / tracing. */
struct bbr2_info {
	int      mode, phase;
	uint64_t bw;			/* bytes/s, model estimate used for pacing */
	uint64_t max_bw;
	uint32_t min_rtt_us;
	uint32_t cwnd;
	uint64_t pacing_rate;
	uint32_t inflight_hi, inflight_lo;
	uint64_t bw_lo;
	uint32_t ecn_alpha;
	uint32_t round_count;
	int      full_bw_reached;
};

struct bbr2 {
	struct bbr2_params p;
	uint32_t mss;
	uint32_t rng;
	uint64_t now_us;

	/* ---- delivery-rate sampler ---- */
	struct bbr2_txrec tx[BBR2_TXRING_SZ];
	uint32_t tx_head, tx_tail;	/* free-running counters */
	uint64_t delivered;		/* total bytes delivered */
	uint64_t delivered_us;		/* time of last delivery */
	uint64_t first_tx_us;
	uint64_t app_limited;		/* 0 or delivered mark */
	int      cand_valid;		/* best sampled record for this ACK */
	uint64_t cand_delivered, cand_delivered_us, cand_send_us;
	uint32_t cand_in_flight;
	int      cand_app_limited, cand_retrans;
	uint32_t pending_lost;		/* from bbr2_on_loss() */
	uint32_t lost_total, ce_total;	/* cumulative counters stamped on records */
	uint32_t cand_lost, cand_ce;

	/* ---- model ---- */
	int      mode, phase;
	uint64_t bw_hi[2];		/* max-bw filter, two probe cycles */
	uint64_t bw_lo;			/* short-term lower bound (INF64 = unset) */
	uint64_t bw_latest;
	uint32_t inflight_hi;		/* long-term upper bound (INF32 = unset) */
	uint32_t inflight_lo;		/* short-term lower bound (INF32 = unset) */
	uint32_t inflight_latest;
	uint32_t min_rtt_us, probe_rtt_min_us;
	uint64_t min_rtt_stamp, probe_rtt_min_stamp;
	uint32_t cwnd, prior_cwnd;
	uint64_t pacing_rate;
	uint32_t pacing_gain, cwnd_gain;

	/* ---- rounds ---- */
	uint64_t next_rtt_delivered;
	uint32_t round_count;
	int      round_start;
	uint32_t rounds_since_probe;

	/* ---- startup ---- */
	int      full_bw_reached;
	int      full_bw_cnt;
	uint64_t full_bw;

	/* ---- congestion signals within the current round ---- */
	uint64_t lost_in_round, delivered_in_round, ce_in_round;
	uint32_t loss_events_in_round;
	uint32_t ecn_alpha;		/* /256 */

	/* ---- probe_bw ---- */
	uint64_t cycle_start_us;
	uint32_t probe_wait_us;
	int      bw_probe_samples;
	int      prev_probe_too_high;
	uint32_t probe_up_cnt, probe_up_acked, probe_up_rounds;
	uint64_t probe_lost, probe_delivered;	/* totals since PROBE_UP began */

	/* ---- probe_rtt ---- */
	uint64_t probe_rtt_done_us;
	int      probe_rtt_round_done;

	/* ---- recovery ---- */
	int      ca_state, prev_ca_state;
	int      packet_conservation;
	int      idle_restart;
	int      has_seen_rtt;
	uint32_t last_rtt_us;		/* most recent RTT sample */

	/* ---- ack aggregation ---- */
	uint64_t ack_epoch_us, ack_epoch_acked;
	uint32_t extra_acked[2];
	int      extra_acked_idx;
	uint32_t extra_acked_win_rtts;
};

/* ----------------------------- API ------------------------------- */

void     bbr2_params_default(struct bbr2_params *p);

/* Initialise a connection.  p may be NULL (defaults).  seed randomises probe
 * timing (use e.g. arc4random()); any value, including 0, is acceptable. */
void     bbr2_init(struct bbr2 *b, const struct bbr2_params *p, uint32_t mss,
	    uint64_t now_us, uint32_t seed);
void     bbr2_set_mss(struct bbr2 *b, uint32_t mss);

/* Transmit path hook: call once for every chunk handed to IP. */
void     bbr2_on_send(struct bbr2 *b, uint32_t seq, uint32_t len,
	    uint32_t inflight_before, int is_retrans, uint64_t now_us);

/* ACK path hooks: call bbr2_on_sack() for each newly SACKed block, then
 * bbr2_on_ack() exactly once per received ACK segment. */
void     bbr2_on_sack(struct bbr2 *b, uint32_t start, uint32_t end);
void     bbr2_on_ack(struct bbr2 *b, const struct bbr2_ack *ack);

/* Loss signals that arrive outside an ACK (timers, tail-loss probes). */
void     bbr2_on_loss(struct bbr2 *b, uint32_t lost_bytes);
void     bbr2_on_rto(struct bbr2 *b, uint32_t inflight, uint64_t now_us);

/* Tell BBR the application had nothing more to send (no cwnd limit). */
void     bbr2_set_app_limited(struct bbr2 *b, uint32_t inflight);

/* Outputs consumed by the stack's output routine and pacer. */
uint32_t bbr2_get_cwnd(const struct bbr2 *b);
uint64_t bbr2_get_pacing_rate(const struct bbr2 *b);
uint32_t bbr2_get_send_quantum(const struct bbr2 *b);
void     bbr2_get_info(const struct bbr2 *b, struct bbr2_info *info);
const char *bbr2_mode_name(const struct bbr2 *b);

/* Sampler internals (bbr2_rate.c). */
void     bbr2_rate_on_send(struct bbr2 *b, uint32_t seq, uint32_t len,
	    uint32_t inflight_before, int is_retrans, uint64_t now_us);
void     bbr2_rate_on_sack(struct bbr2 *b, uint32_t start, uint32_t end);
void     bbr2_rate_cum_ack(struct bbr2 *b, uint32_t ack_seq);
void     bbr2_rate_gen(struct bbr2 *b, const struct bbr2_ack *a,
	    struct bbr2_rs *rs);

#endif /* BBR2_H */
