/*
 * bbr2_priv.h - helpers shared between bbr2.c and bbr2_model.c.  Not part of
 * the public API.
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#ifndef BBR2_PRIV_H
#define BBR2_PRIV_H

#include "bbr2.h"

#define US_PER_MS	1000ULL
#define US_PER_SEC	1000000ULL

uint32_t bbr2_rand(struct bbr2 *b);
uint64_t bbr2_max_bw(const struct bbr2 *b);
uint64_t bbr2_cur_bw(const struct bbr2 *b);	/* min(max_bw, bw_lo) */
uint32_t bbr2_min_cwnd(const struct bbr2 *b);
uint32_t bbr2_send_quantum(const struct bbr2 *b);
int      bbr2_is_probing_bw(const struct bbr2 *b);
uint64_t bbr2_bdp(const struct bbr2 *b, uint64_t bw, uint32_t gain);
uint32_t bbr2_inflight_at(const struct bbr2 *b, uint64_t bw, uint32_t gain);
uint32_t bbr2_target_inflight(const struct bbr2 *b);
uint32_t bbr2_inflight_with_headroom(const struct bbr2 *b);
uint32_t bbr2_probe_rtt_cwnd(const struct bbr2 *b);
void     bbr2_reset_lower_bounds(struct bbr2 *b);
void     bbr2_set_pacing_rate(struct bbr2 *b, uint64_t bw, uint32_t gain);
void     bbr2_init_pacing_rate_from_rtt(struct bbr2 *b, uint64_t rtt_us);
void     bbr2_update_gains(struct bbr2 *b);

#endif /* BBR2_PRIV_H */
