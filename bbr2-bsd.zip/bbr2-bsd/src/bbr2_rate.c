/*
 * bbr2_rate.c - delivery-rate sampler.
 *
 * Implements the "delivery rate estimation" algorithm
 * (draft-cheng-iccrg-delivery-rate-estimation): each transmitted chunk is
 * stamped with the connection's delivery counters; when it is (S)ACKed the
 * difference between "now" and the stamp gives bytes delivered over an
 * interval, i.e. a bandwidth sample.  Stock BSD TCP keeps no per-packet
 * state, so this file keeps a small ring of send records instead.
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#include "bbr2.h"

#define RING_MASK	(BBR2_TXRING_SZ - 1)
#define US_PER_SEC	1000000ULL

static inline int seq_leq(uint32_t a, uint32_t b) { return (int32_t)(a - b) <= 0; }

static inline struct bbr2_txrec *
ring_at(struct bbr2 *b, uint32_t idx)
{
	return &b->tx[idx & RING_MASK];
}

void
bbr2_rate_on_send(struct bbr2 *b, uint32_t seq, uint32_t len,
    uint32_t inflight_before, int is_retrans, uint64_t now_us)
{
	struct bbr2_txrec *r;

	if (len == 0)
		return;
	/* Pipe was empty: start a fresh sampling epoch so the first sample
	 * does not include idle time. */
	if (inflight_before == 0) {
		b->first_tx_us = now_us;
		b->delivered_us = now_us;
	}
	/* Ring full (more chunks in flight than BBR2_TXRING_SZ): do not record
	 * this chunk.  Older records keep producing samples, just less often.
	 * (Dropping the OLDEST record instead would starve the sampler: ACKs
	 * would always lag behind the ring head.) */
	if (b->tx_tail - b->tx_head >= BBR2_TXRING_SZ)
		return;

	r = ring_at(b, b->tx_tail++);
	r->sent_us = now_us;
	r->delivered = b->delivered;
	r->delivered_us = b->delivered_us;
	r->first_tx_us = b->first_tx_us;
	r->start_seq = seq;
	r->end_seq = seq + len;
	r->in_flight = inflight_before + len;
	r->lost = b->lost_total;
	r->ce = b->ce_total;
	r->app_limited = b->app_limited != 0;
	r->is_retrans = is_retrans != 0;
	r->acked = 0;
	r->pad = 0;
}

/* Consider a newly acknowledged record as the sample for this ACK.  Among all
 * records acked by one ACK we keep the one that was sent most recently
 * (largest 'delivered' stamp): it has the shortest, most accurate interval. */
static void
consider(struct bbr2 *b, const struct bbr2_txrec *r)
{
	if (!b->cand_valid || r->delivered > b->cand_delivered) {
		b->cand_valid = 1;
		b->cand_delivered = r->delivered;
		b->cand_delivered_us = r->delivered_us;
		b->cand_send_us = r->sent_us - r->first_tx_us;
		b->cand_in_flight = r->in_flight;
		b->cand_lost = r->lost;
		b->cand_ce = r->ce;
		b->cand_app_limited = r->app_limited;
		b->cand_retrans = r->is_retrans;
		b->first_tx_us = r->sent_us;
	}
}

/* A SACK block [start,end) arrived: mark every record fully inside it.
 * O(ring size) per block; only executed on ACKs that carry SACK. */
void
bbr2_rate_on_sack(struct bbr2 *b, uint32_t start, uint32_t end)
{
	uint32_t i;

	for (i = b->tx_head; i != b->tx_tail; i++) {
		struct bbr2_txrec *r = ring_at(b, i);

		if (!r->acked && seq_leq(start, r->start_seq) &&
		    seq_leq(r->end_seq, end)) {
			r->acked = 1;
			consider(b, r);
		}
	}
}

/* Cumulative ACK advanced to ack_seq: retire all records at or below it. */
void
bbr2_rate_cum_ack(struct bbr2 *b, uint32_t ack_seq)
{
	while (b->tx_head != b->tx_tail) {
		struct bbr2_txrec *r = ring_at(b, b->tx_head);

		if (!seq_leq(r->end_seq, ack_seq))
			break;
		if (!r->acked)
			consider(b, r);
		b->tx_head++;
	}
}

/* Finish the sample for this ACK; updates delivered counters. */
void
bbr2_rate_gen(struct bbr2 *b, const struct bbr2_ack *a, struct bbr2_rs *rs)
{
	uint64_t ack_us, interval;

	BBR2_ZERO(rs, sizeof(*rs));
	rs->acked = a->acked_bytes;
	rs->lost = a->lost_bytes + b->pending_lost;
	rs->ce = a->ce_bytes;
	rs->inflight = a->inflight;
	b->pending_lost = 0;
	b->lost_total += rs->lost;
	b->ce_total += a->ce_bytes;
	rs->lost_interval = rs->lost;	/* refined below if a sample exists */
	rs->ce_interval = rs->ce;

	if (a->acked_bytes) {
		b->delivered += a->acked_bytes;
		b->delivered_us = a->now_us;
	}
	/* Leave app-limited mode once data sent after the mark is delivered. */
	if (b->app_limited && b->delivered > b->app_limited)
		b->app_limited = 0;

	if (!b->cand_valid)
		return;
	b->cand_valid = 0;

	rs->have_prior = 1;
	rs->prior_delivered = b->cand_delivered;
	rs->tx_in_flight = b->cand_in_flight;
	rs->lost_interval = b->lost_total - b->cand_lost;
	rs->ce_interval = b->ce_total - b->cand_ce;
	rs->is_app_limited = b->cand_app_limited;
	rs->delivered = b->delivered - b->cand_delivered;
	ack_us = a->now_us - b->cand_delivered_us;
	interval = BBR2_MAX(b->cand_send_us, ack_us);
	rs->interval_us = interval;

	/* An interval shorter than the min RTT is physically impossible for a
	 * fresh sample (ACK compression); discard it unless retransmitted. */
	if (!b->cand_retrans && b->min_rtt_us != BBR2_INF32 &&
	    interval < b->min_rtt_us)
		return;
	if (rs->delivered == 0 || interval == 0)
		return;
	rs->bw = rs->delivered * US_PER_SEC / interval;
	rs->valid = 1;
}
