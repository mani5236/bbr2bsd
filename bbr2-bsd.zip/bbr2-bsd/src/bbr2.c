/*
 * bbr2.c - BBRv2: parameters, initialisation, model arithmetic and getters.
 * The per-ACK state machine lives in bbr2_model.c.
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#include "bbr2_priv.h"

void
bbr2_params_default(struct bbr2_params *p)
{
	p->high_gain = 739;		/* 2/ln(2) */
	p->drain_gain = 88;		/* ln(2)/2 */
	p->startup_cwnd_gain = 512;
	p->cwnd_gain = 512;
	p->probe_up_gain = 320;
	p->probe_down_gain = 192;
	p->beta = 179;
	p->loss_thresh_ppt = 20;
	p->ecn_thresh = 128;
	p->ecn_factor = 85;
	p->ecn_alpha_gain_shift = 4;
	p->ecn_alpha_init = 0;
	p->headroom_pct = 15;
	p->full_bw_thresh = 320;
	p->full_bw_cnt = 3;
	p->full_loss_cnt = 6;
	p->pacing_margin_pct = 1;
	p->min_rtt_win_ms = 10000;
	p->probe_rtt_win_ms = 5000;
	p->probe_rtt_dur_ms = 200;
	p->probe_rtt_cwnd_gain = 128;
	p->probe_wait_base_ms = 2000;
	p->probe_wait_rand_ms = 1000;
	p->probe_rand_rounds = 2;
	p->probe_max_rounds = 63;
	p->probe_reno_gain = 256;
	p->probe_up_max_rounds = 30;
	p->extra_acked_gain = 256;
	p->extra_acked_win_rtts = 5;
	p->min_cwnd_segs = 4;
	p->init_cwnd_segs = 10;
	p->max_quantum = 65536;
}

/* xorshift32; deterministic, no OS dependency. */
uint32_t
bbr2_rand(struct bbr2 *b)
{
	uint32_t x = b->rng;

	x ^= x << 13;
	x ^= x >> 17;
	x ^= x << 5;
	b->rng = x;
	return x;
}

void
bbr2_init(struct bbr2 *b, const struct bbr2_params *p, uint32_t mss,
    uint64_t now_us, uint32_t seed)
{
	BBR2_ZERO(b, sizeof(*b));
	if (p != NULL)
		b->p = *p;
	else
		bbr2_params_default(&b->p);
	BBR2_ASSERT((BBR2_TXRING_SZ & (BBR2_TXRING_SZ - 1)) == 0);
	b->mss = mss ? mss : 1448;
	b->rng = seed ? seed : 2463534242u;
	b->now_us = now_us;

	b->mode = BBR2_STARTUP;
	b->phase = BBR2_PHASE_DOWN;
	b->bw_lo = BBR2_INF64;
	b->inflight_hi = BBR2_INF32;
	b->inflight_lo = BBR2_INF32;
	b->min_rtt_us = BBR2_INF32;
	b->probe_rtt_min_us = BBR2_INF32;
	b->min_rtt_stamp = now_us;
	b->probe_rtt_min_stamp = now_us;
	b->cwnd = b->p.init_cwnd_segs * b->mss;
	b->prior_cwnd = b->cwnd;
	b->ecn_alpha = b->p.ecn_alpha_init;
	b->probe_up_cnt = BBR2_INF32;
	b->ack_epoch_us = now_us;
	b->first_tx_us = now_us;
	b->delivered_us = now_us;
	bbr2_update_gains(b);
	/* Assume 1 ms RTT until a real sample arrives (as Linux BBR does). */
	bbr2_init_pacing_rate_from_rtt(b, 1000);
	b->has_seen_rtt = 0;
}

void
bbr2_set_mss(struct bbr2 *b, uint32_t mss)
{
	if (mss)
		b->mss = mss;
}

/* ---------------------------------------------------------------- */
/* Model arithmetic                                                  */
/* ---------------------------------------------------------------- */

uint64_t
bbr2_max_bw(const struct bbr2 *b)
{
	return BBR2_MAX(b->bw_hi[0], b->bw_hi[1]);
}

uint64_t
bbr2_cur_bw(const struct bbr2 *b)
{
	return BBR2_MIN(bbr2_max_bw(b), b->bw_lo);
}

uint32_t
bbr2_min_cwnd(const struct bbr2 *b)
{
	return b->p.min_cwnd_segs * b->mss;
}

/* Largest burst the pacer should release at once: ~1 ms of data. */
uint32_t
bbr2_send_quantum(const struct bbr2 *b)
{
	uint64_t q = b->pacing_rate / 1000;

	q = BBR2_MIN(q, b->p.max_quantum);
	q = BBR2_MAX(q, 2ULL * b->mss);
	return (uint32_t)q;
}

int
bbr2_is_probing_bw(const struct bbr2 *b)
{
	return b->mode == BBR2_STARTUP ||
	    (b->mode == BBR2_PROBE_BW &&
	    (b->phase == BBR2_PHASE_REFILL || b->phase == BBR2_PHASE_UP));
}

/* bandwidth-delay product at the given bw and gain, in bytes. */
uint64_t
bbr2_bdp(const struct bbr2 *b, uint64_t bw, uint32_t gain)
{
	uint64_t v;

	if (b->min_rtt_us == BBR2_INF32)
		return (uint64_t)b->p.init_cwnd_segs * b->mss;
	v = bw * b->min_rtt_us / US_PER_SEC;
	return (v * gain) >> BBR2_SCALE;
}

/* BDP plus a few quanta so the pacer / TSO bursts never starve the pipe. */
uint32_t
bbr2_inflight_at(const struct bbr2 *b, uint64_t bw, uint32_t gain)
{
	uint64_t v = bbr2_bdp(b, bw, gain) + 3ULL * bbr2_send_quantum(b);

	if (b->mode == BBR2_PROBE_BW && b->phase == BBR2_PHASE_UP)
		v += 2ULL * b->mss;	/* make sure the probe can exceed the BDP */
	return v > BBR2_INF32 - 1 ? BBR2_INF32 - 1 : (uint32_t)v;
}

/* Estimated BDP, capped by the current window (no quantisation slack). */
uint32_t
bbr2_target_inflight(const struct bbr2 *b)
{
	uint64_t bdp = bbr2_bdp(b, bbr2_cur_bw(b), BBR2_UNIT);

	return (uint32_t)BBR2_MIN(bdp, b->cwnd);
}

/* inflight_hi minus the safety margin left for other flows to enter. */
uint32_t
bbr2_inflight_with_headroom(const struct bbr2 *b)
{
	uint64_t hr;
	uint32_t hi = b->inflight_hi;

	if (hi == BBR2_INF32)
		return BBR2_INF32;
	hr = (uint64_t)hi * b->p.headroom_pct / 100;
	hr = BBR2_MAX(hr, b->mss);
	hi = hi > hr ? (uint32_t)(hi - hr) : 0;
	return BBR2_MAX(hi, bbr2_min_cwnd(b));
}

uint32_t
bbr2_probe_rtt_cwnd(const struct bbr2 *b)
{
	uint64_t c = bbr2_bdp(b, bbr2_cur_bw(b), b->p.probe_rtt_cwnd_gain);

	return (uint32_t)BBR2_MAX(c, bbr2_min_cwnd(b));
}

void
bbr2_reset_lower_bounds(struct bbr2 *b)
{
	b->bw_lo = BBR2_INF64;
	b->inflight_lo = BBR2_INF32;
}

/* Pick pacing/cwnd gains for the current mode (call after every mode change). */
void
bbr2_update_gains(struct bbr2 *b)
{
	switch (b->mode) {
	case BBR2_STARTUP:
		b->pacing_gain = b->p.high_gain;
		b->cwnd_gain = b->p.startup_cwnd_gain;
		break;
	case BBR2_DRAIN:
		b->pacing_gain = b->p.drain_gain;
		b->cwnd_gain = b->p.startup_cwnd_gain;
		break;
	case BBR2_PROBE_BW:
		b->cwnd_gain = b->p.cwnd_gain;
		switch (b->phase) {
		case BBR2_PHASE_UP:
			b->pacing_gain = b->p.probe_up_gain;
			break;
		case BBR2_PHASE_DOWN:
			b->pacing_gain = b->p.probe_down_gain;
			break;
		default:
			b->pacing_gain = BBR2_UNIT;
		}
		break;
	default: /* PROBE_RTT */
		b->pacing_gain = BBR2_UNIT;
		b->cwnd_gain = BBR2_UNIT;
	}
}

void
bbr2_set_pacing_rate(struct bbr2 *b, uint64_t bw, uint32_t gain)
{
	uint64_t rate = (bw * gain) >> BBR2_SCALE;

	rate = rate * (100 - b->p.pacing_margin_pct) / 100;
	/* Before the pipe is full never lower the rate: bw estimate is
	 * still ramping up. */
	if (b->full_bw_reached || rate > b->pacing_rate)
		b->pacing_rate = rate;
}

void
bbr2_init_pacing_rate_from_rtt(struct bbr2 *b, uint64_t rtt_us)
{
	uint64_t bw;

	if (rtt_us == 0)
		rtt_us = 1000;
	b->has_seen_rtt = 1;
	bw = (uint64_t)b->cwnd * US_PER_SEC / rtt_us;
	b->pacing_rate = 0;
	{
		uint64_t rate = (bw * b->p.high_gain) >> BBR2_SCALE;

		b->pacing_rate = rate * (100 - b->p.pacing_margin_pct) / 100;
	}
}

/* ---------------------------------------------------------------- */
/* Public getters and thin wrappers                                  */
/* ---------------------------------------------------------------- */

void
bbr2_on_send(struct bbr2 *b, uint32_t seq, uint32_t len,
    uint32_t inflight_before, int is_retrans, uint64_t now_us)
{
	bbr2_rate_on_send(b, seq, len, inflight_before, is_retrans, now_us);
	/* Restarting from idle: don't treat the gap as congestion; resume
	 * at the estimated bandwidth immediately. */
	if (inflight_before == 0 && b->app_limited) {
		b->idle_restart = 1;
		b->ack_epoch_us = now_us;
		b->ack_epoch_acked = 0;
		if (b->mode == BBR2_PROBE_BW)
			bbr2_set_pacing_rate(b, bbr2_cur_bw(b), BBR2_UNIT);
	}
}

void
bbr2_on_sack(struct bbr2 *b, uint32_t start, uint32_t end)
{
	bbr2_rate_on_sack(b, start, end);
}

uint32_t
bbr2_get_cwnd(const struct bbr2 *b)
{
	return b->cwnd;
}

uint64_t
bbr2_get_pacing_rate(const struct bbr2 *b)
{
	return b->pacing_rate;
}

uint32_t
bbr2_get_send_quantum(const struct bbr2 *b)
{
	return bbr2_send_quantum(b);
}

void
bbr2_get_info(const struct bbr2 *b, struct bbr2_info *i)
{
	i->mode = b->mode;
	i->phase = b->phase;
	i->bw = bbr2_cur_bw(b);
	i->max_bw = bbr2_max_bw(b);
	i->min_rtt_us = b->min_rtt_us;
	i->cwnd = b->cwnd;
	i->pacing_rate = b->pacing_rate;
	i->inflight_hi = b->inflight_hi;
	i->inflight_lo = b->inflight_lo;
	i->bw_lo = b->bw_lo;
	i->ecn_alpha = b->ecn_alpha;
	i->round_count = b->round_count;
	i->full_bw_reached = b->full_bw_reached;
}

const char *
bbr2_mode_name(const struct bbr2 *b)
{
	static const char *const n[] = { "STARTUP", "DRAIN", "PROBE_BW", "PROBE_RTT" };
	static const char *const bw[] = { "PROBE_BW/DOWN", "PROBE_BW/CRUISE",
	    "PROBE_BW/REFILL", "PROBE_BW/UP" };

	return b->mode == BBR2_PROBE_BW ? bw[b->phase] : n[b->mode];
}
