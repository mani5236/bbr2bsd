/*
 * bbr2_model.c - BBRv2 per-ACK state machine.
 *
 *   STARTUP -> DRAIN -> PROBE_BW { DOWN -> CRUISE -> REFILL -> UP -> DOWN ... }
 *                          \-> PROBE_RTT (every ~5 s) -> PROBE_BW
 *
 * Model variables maintained per ACK:
 *   bw_hi[]      max delivery rate over the last two probe cycles
 *   bw_lo        short-term bound, lowered when loss is seen outside probing
 *   inflight_hi  long-term upper bound, learned from loss/ECN while probing
 *   inflight_lo  short-term bound, lowered on loss/ECN outside probing
 *   min_rtt      propagation delay estimate
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#include "bbr2_priv.h"

/* ------------------------------------------------------------------ */
/* Bandwidth filter, rounds, ack aggregation                           */
/* ------------------------------------------------------------------ */

static void
update_round(struct bbr2 *b, const struct bbr2_rs *rs)
{
	b->round_start = 0;
	if (rs->have_prior && rs->prior_delivered >= b->next_rtt_delivered) {
		b->next_rtt_delivered = b->delivered;
		b->round_count++;
		b->rounds_since_probe++;
		b->round_start = 1;
		b->packet_conservation = 0;
	}
}

static void
update_bw(struct bbr2 *b, const struct bbr2_rs *rs)
{
	if (!rs->valid)
		return;
	b->bw_latest = BBR2_MAX(b->bw_latest, rs->bw);
	/* App-limited samples may only raise the estimate, never define it. */
	if (!rs->is_app_limited || rs->bw >= bbr2_max_bw(b))
		b->bw_hi[1] = BBR2_MAX(b->bw_hi[1], rs->bw);
}

/* Slide the 2-slot max filter; called once per probing cycle. */
static void
advance_bw_hi(struct bbr2 *b)
{
	if (b->bw_hi[1] == 0)
		return;
	b->bw_hi[0] = b->bw_hi[1];
	b->bw_hi[1] = 0;
}

/* Estimate how many bytes ACK aggregation (wifi, LRO, ACK thinning) delivers
 * beyond what bw*time predicts, so cwnd can absorb it. */
static void
update_ack_aggregation(struct bbr2 *b, const struct bbr2_rs *rs)
{
	uint64_t epoch_us, expected, extra;

	if (!b->p.extra_acked_gain || rs->acked == 0)
		return;
	if (b->round_start) {
		if (++b->extra_acked_win_rtts >= b->p.extra_acked_win_rtts) {
			b->extra_acked_win_rtts = 0;
			b->extra_acked_idx ^= 1;
			b->extra_acked[b->extra_acked_idx] = 0;
		}
	}
	epoch_us = b->now_us - b->ack_epoch_us;
	expected = bbr2_cur_bw(b) * epoch_us / US_PER_SEC;
	if (b->ack_epoch_acked <= expected ||
	    b->ack_epoch_acked + rs->acked >= (1ULL << 30)) {
		b->ack_epoch_acked = 0;
		b->ack_epoch_us = b->now_us;
		expected = 0;
	}
	b->ack_epoch_acked += rs->acked;
	extra = b->ack_epoch_acked - expected;
	extra = BBR2_MIN(extra, b->cwnd);
	if (extra > b->extra_acked[b->extra_acked_idx])
		b->extra_acked[b->extra_acked_idx] = (uint32_t)extra;
}

static uint32_t
aggr_cwnd(const struct bbr2 *b)
{
	uint64_t aggr, cap;

	if (!b->p.extra_acked_gain || !b->full_bw_reached)
		return 0;
	aggr = ((uint64_t)b->p.extra_acked_gain *
	    BBR2_MAX(b->extra_acked[0], b->extra_acked[1])) >> BBR2_SCALE;
	cap = bbr2_cur_bw(b) / 10;		/* 100 ms of data */
	return (uint32_t)BBR2_MIN(aggr, cap);
}

/* ------------------------------------------------------------------ */
/* Loss / ECN signals                                                  */
/* ------------------------------------------------------------------ */

/* Short-term response: outside of probing, shrink bw_lo/inflight_lo. */
static void
adapt_lower_bounds(struct bbr2 *b)
{
	if (b->lost_in_round > 0) {
		if (b->bw_lo == BBR2_INF64)
			b->bw_lo = bbr2_max_bw(b);
		if (b->inflight_lo == BBR2_INF32)
			b->inflight_lo = b->cwnd;
		b->bw_lo = BBR2_MAX(b->bw_latest,
		    (b->bw_lo * b->p.beta) >> BBR2_SCALE);
		b->inflight_lo = (uint32_t)BBR2_MAX(
		    (uint64_t)b->inflight_latest,
		    ((uint64_t)b->inflight_lo * b->p.beta) >> BBR2_SCALE);
		b->inflight_lo = BBR2_MAX(b->inflight_lo, bbr2_min_cwnd(b));
	}
	if (b->ce_in_round > 0 && b->p.ecn_factor && b->ecn_alpha) {
		uint32_t cut = BBR2_UNIT -
		    ((b->p.ecn_factor * b->ecn_alpha) >> BBR2_SCALE);
		uint32_t lo = (uint32_t)(((uint64_t)b->cwnd * cut) >> BBR2_SCALE);

		lo = BBR2_MAX(lo, bbr2_min_cwnd(b));
		b->inflight_lo = BBR2_MIN(b->inflight_lo, lo);
	}
}

static void
update_ecn_alpha(struct bbr2 *b)
{
	uint32_t frac;

	if (b->delivered_in_round == 0)
		return;
	frac = (uint32_t)BBR2_MIN(b->ce_in_round * BBR2_UNIT /
	    b->delivered_in_round, BBR2_UNIT);
	b->ecn_alpha = b->ecn_alpha - (b->ecn_alpha >> b->p.ecn_alpha_gain_shift) +
	    (frac >> b->p.ecn_alpha_gain_shift);
}

static void
update_signals(struct bbr2 *b, const struct bbr2_rs *rs)
{
	if (rs->valid)
		b->inflight_latest = (uint32_t)BBR2_MAX(b->inflight_latest,
		    BBR2_MIN(rs->delivered, BBR2_INF32 - 1));
	b->lost_in_round += rs->lost;
	b->delivered_in_round += rs->acked;
	b->ce_in_round += rs->ce;
	if (rs->lost > 0)
		b->loss_events_in_round++;
	if (!b->round_start)
		return;

	/* ---- once per round trip ---- */
	if (b->mode == BBR2_STARTUP && !b->full_bw_reached &&
	    b->loss_events_in_round >= b->p.full_loss_cnt &&
	    b->lost_in_round * 1000 >
	    (b->lost_in_round + b->delivered_in_round) * b->p.loss_thresh_ppt) {
		/* STARTUP is overshooting a shallow buffer: stop growing. */
		b->inflight_hi = BBR2_MAX(bbr2_target_inflight(b),
		    b->inflight_latest);
		b->full_bw_reached = 1;
	}
	update_ecn_alpha(b);
	if (!bbr2_is_probing_bw(b))
		adapt_lower_bounds(b);
	b->bw_latest = 0;
	b->inflight_latest = 0;
	b->lost_in_round = 0;
	b->delivered_in_round = 0;
	b->ce_in_round = 0;
	b->loss_events_in_round = 0;
}

/* ------------------------------------------------------------------ */
/* PROBE_BW phases                                                     */
/* ------------------------------------------------------------------ */

static void
pick_probe_wait(struct bbr2 *b)
{
	b->rounds_since_probe = b->p.probe_rand_rounds ?
	    bbr2_rand(b) % b->p.probe_rand_rounds : 0;
	b->probe_wait_us = (uint32_t)(b->p.probe_wait_base_ms * US_PER_MS +
	    (b->p.probe_wait_rand_ms ?
	    bbr2_rand(b) % (b->p.probe_wait_rand_ms * US_PER_MS) : 0));
}

static void
start_probe_down(struct bbr2 *b)
{
	b->mode = BBR2_PROBE_BW;
	b->phase = BBR2_PHASE_DOWN;
	b->bw_probe_samples = 0;
	b->probe_up_cnt = BBR2_INF32;
	b->cycle_start_us = b->now_us;
	pick_probe_wait(b);
	advance_bw_hi(b);
}

static void
start_probe_cruise(struct bbr2 *b)
{
	b->phase = BBR2_PHASE_CRUISE;
}

static void
start_probe_refill(struct bbr2 *b)
{
	bbr2_reset_lower_bounds(b);
	b->probe_up_rounds = 0;
	b->probe_up_acked = 0;
	b->prev_probe_too_high = 0;
	b->next_rtt_delivered = b->delivered;	/* refill lasts one round */
	b->cycle_start_us = b->now_us;
	b->phase = BBR2_PHASE_REFILL;
}

/* Exponentially faster inflight_hi growth while probing keeps succeeding. */
static void
raise_inflight_hi_slope(struct bbr2 *b)
{
	uint32_t shift = BBR2_MIN(b->probe_up_rounds, b->p.probe_up_max_rounds);

	b->probe_up_cnt = BBR2_MAX(b->cwnd >> shift, b->mss);
	if (b->probe_up_rounds < b->p.probe_up_max_rounds)
		b->probe_up_rounds++;
}

static void
start_probe_up(struct bbr2 *b)
{
	b->bw_probe_samples = 1;
	b->probe_up_acked = 0;
	b->probe_lost = 0;
	b->probe_delivered = 0;
	b->cycle_start_us = b->now_us;
	b->phase = BBR2_PHASE_UP;
	b->probe_up_cnt = BBR2_INF32;
	raise_inflight_hi_slope(b);
}

static int
has_elapsed_in_phase(const struct bbr2 *b, uint64_t us)
{
	return b->now_us > b->cycle_start_us + us;
}

/* Reno coexistence: probe at least every ~BDP (in packets) rounds so that we
 * recover bandwidth from loss-based flows sharing the bottleneck. */
static int
reno_probe_time(const struct bbr2 *b)
{
	uint64_t pkts = bbr2_target_inflight(b) / b->mss;
	uint64_t rounds = (pkts * b->p.probe_reno_gain) >> BBR2_SCALE;

	rounds = BBR2_MIN(rounds, b->p.probe_max_rounds);
	rounds = BBR2_MAX(rounds, 1);
	return b->rounds_since_probe >= rounds;
}

static int
time_to_cruise(const struct bbr2 *b, uint32_t inflight)
{
	if (inflight > bbr2_inflight_with_headroom(b))
		return 0;
	return inflight <= bbr2_inflight_at(b, bbr2_max_bw(b), BBR2_UNIT);
}

static void
update_cycle_phase(struct bbr2 *b, const struct bbr2_ack *a)
{
	switch (b->phase) {
	case BBR2_PHASE_DOWN:
		if (time_to_cruise(b, a->inflight))
			start_probe_cruise(b);
		break;
	case BBR2_PHASE_CRUISE:
		if (has_elapsed_in_phase(b, b->probe_wait_us) ||
		    reno_probe_time(b))
			start_probe_refill(b);
		break;
	case BBR2_PHASE_REFILL:
		if (b->round_start)
			start_probe_up(b);
		break;
	case BBR2_PHASE_UP:
		if (b->min_rtt_us != BBR2_INF32 &&
		    has_elapsed_in_phase(b, b->min_rtt_us) &&
		    a->inflight > bbr2_inflight_at(b, bbr2_max_bw(b),
		    b->p.probe_up_gain))
			start_probe_down(b);
		break;
	}
}

/* ------------------------------------------------------------------ */
/* inflight_hi: the long-term, loss/ECN-derived bound                  */
/* ------------------------------------------------------------------ */

static uint32_t
rs_tx_inflight(const struct bbr2_rs *rs)
{
	return rs->tx_in_flight ? rs->tx_in_flight : rs->inflight + rs->acked;
}

static int
is_inflight_too_high(const struct bbr2_rs *rs, const struct bbr2 *b)
{
	uint32_t txif = rs_tx_inflight(rs);

	/*
	 * Loss is judged two ways while probing:
	 *  - interval test: lost bytes over the sample interval (everything
	 *    lost since the sampled chunk was sent) exceed the threshold of
	 *    the data in flight when it was sent: 1x if a queue is visible in
	 *    the RTT (loss is then congestion), 2x otherwise.  Catches buffer
	 *    overflow, which drops a cluster of packets at once.
	 *  - sustained test: lost bytes since PROBE_UP began exceed the
	 *    threshold of everything seen in the probe, once at least half a
	 *    BDP has been observed.
	 * Using the plain interval test at 1x threshold treats ~1.5% random
	 * loss as congestion (Poisson noise over a few hundred packets) and
	 * ratchets inflight_hi down; the two-tier form tolerates it.
	 * ECN marks are judged over the sample interval.
	 *
	 * The interval tests run in every phase: a "too high" verdict outside
	 * of probing does not lower inflight_hi, but it does stop inflight_hi
	 * from being raised to the current inflight (see adapt_upper_bounds),
	 * which is what lets an incumbent flow give way to newcomers.
	 */
	if (rs->lost_interval > 0 && txif) {
		uint64_t thr = (uint64_t)txif * b->p.loss_thresh_ppt;
		int queue_seen = b->min_rtt_us != BBR2_INF32 &&
		    b->last_rtt_us > b->min_rtt_us + (b->min_rtt_us >> 3);

		/* With a standing queue (RTT > min_rtt + 12.5%) loss is
		 * congestion: use the plain threshold.  Without one, random
		 * loss is the likelier cause: require twice the threshold. */
		if ((uint64_t)rs->lost_interval * 1000 > (queue_seen ? thr : 2 * thr))
			return 1;
	}
	if (b->bw_probe_samples && b->probe_lost > 0) {
		uint64_t seen = b->probe_lost + b->probe_delivered;

		if (seen >= BBR2_MAX((uint64_t)bbr2_target_inflight(b) / 2,
		    8ULL * b->mss) &&
		    b->probe_lost * 1000 > seen * b->p.loss_thresh_ppt)
			return 1;
	}
	if (rs->ce_interval > 0 && rs->delivered > 0 &&
	    rs->ce_interval * (uint64_t)BBR2_UNIT >
	    rs->delivered * b->p.ecn_thresh)
		return 1;
	return 0;
}

static void
handle_inflight_too_high(struct bbr2 *b, const struct bbr2_rs *rs)
{
	b->prev_probe_too_high = 1;
	b->bw_probe_samples = 0;
	if (!rs->is_app_limited) {
		uint64_t floor = ((uint64_t)bbr2_target_inflight(b) *
		    (BBR2_UNIT - b->p.beta)) >> BBR2_SCALE;

		b->inflight_hi = (uint32_t)BBR2_MAX(rs_tx_inflight(rs), floor);
	}
	if (b->mode == BBR2_PROBE_BW && b->phase == BBR2_PHASE_UP)
		start_probe_down(b);
}

static void
probe_inflight_hi_upward(struct bbr2 *b, const struct bbr2_rs *rs,
    const struct bbr2_ack *a)
{
	int cwnd_limited = a->inflight + a->acked_bytes + b->mss >= b->cwnd;

	if (!cwnd_limited || b->cwnd < b->inflight_hi)
		return;			/* not using inflight_hi: don't grow */
	b->probe_up_acked += rs->acked;
	if (b->probe_up_cnt != BBR2_INF32 && b->probe_up_acked >= b->probe_up_cnt) {
		uint32_t delta = b->probe_up_acked / b->probe_up_cnt;

		b->probe_up_acked -= delta * b->probe_up_cnt;
		b->inflight_hi += delta * b->mss;
	}
	if (b->round_start)
		raise_inflight_hi_slope(b);
}

static void
adapt_upper_bounds(struct bbr2 *b, const struct bbr2_rs *rs,
    const struct bbr2_ack *a)
{
	if (b->bw_probe_samples) {
		b->probe_lost += rs->lost;
		b->probe_delivered += rs->acked;
	}
	if (is_inflight_too_high(rs, b)) {
		if (b->bw_probe_samples)
			handle_inflight_too_high(b, rs);
		return;
	}
	if (b->inflight_hi == BBR2_INF32)
		return;			/* no excess-queue signal seen yet */
	/* Resilience to random loss: any phase that proves a higher level
	 * safe raises the bound. */
	if (rs->tx_in_flight > b->inflight_hi)
		b->inflight_hi = rs->tx_in_flight;
	if (b->mode == BBR2_PROBE_BW && b->phase == BBR2_PHASE_UP)
		probe_inflight_hi_upward(b, rs, a);
}

/* ------------------------------------------------------------------ */
/* STARTUP / DRAIN                                                     */
/* ------------------------------------------------------------------ */

static void
check_full_bw_reached(struct bbr2 *b, const struct bbr2_rs *rs)
{
	uint64_t thresh;

	if (b->full_bw_reached || !b->round_start || rs->is_app_limited)
		return;
	thresh = (b->full_bw * b->p.full_bw_thresh) >> BBR2_SCALE;
	if (bbr2_max_bw(b) >= thresh) {
		b->full_bw = bbr2_max_bw(b);
		b->full_bw_cnt = 0;
		return;
	}
	if (++b->full_bw_cnt >= (int)b->p.full_bw_cnt)
		b->full_bw_reached = 1;
}

static void
update_mode(struct bbr2 *b, const struct bbr2_rs *rs, const struct bbr2_ack *a)
{
	if (b->mode == BBR2_STARTUP) {
		check_full_bw_reached(b, rs);
		if (b->full_bw_reached)
			b->mode = BBR2_DRAIN;
	}
	if (b->mode == BBR2_DRAIN &&
	    a->inflight <= bbr2_inflight_at(b, bbr2_max_bw(b), BBR2_UNIT))
		start_probe_down(b);
	if (b->mode == BBR2_PROBE_BW)
		update_cycle_phase(b, a);
}

/* ------------------------------------------------------------------ */
/* min RTT and PROBE_RTT                                               */
/* ------------------------------------------------------------------ */

static void
exit_probe_rtt(struct bbr2 *b)
{
	b->probe_rtt_min_stamp = b->now_us;
	if (b->prior_cwnd > b->cwnd)
		b->cwnd = b->prior_cwnd;		/* restore */
	bbr2_reset_lower_bounds(b);
	if (b->full_bw_reached) {
		start_probe_down(b);
		start_probe_cruise(b);
	} else {
		b->mode = BBR2_STARTUP;
		b->full_bw = 0;
		b->full_bw_cnt = 0;
	}
}

static void
update_min_rtt(struct bbr2 *b, const struct bbr2_ack *a)
{
	int probe_rtt_expired, min_rtt_expired;

	probe_rtt_expired = b->now_us >
	    b->probe_rtt_min_stamp + b->p.probe_rtt_win_ms * US_PER_MS;
	if (a->rtt_us >= 0 && (a->rtt_us <= (int64_t)b->probe_rtt_min_us ||
	    probe_rtt_expired)) {
		b->probe_rtt_min_us = (uint32_t)BBR2_MIN((uint64_t)a->rtt_us,
		    BBR2_INF32 - 1);
		b->probe_rtt_min_stamp = b->now_us;
	}
	min_rtt_expired = b->now_us >
	    b->min_rtt_stamp + b->p.min_rtt_win_ms * US_PER_MS;
	if (b->probe_rtt_min_us <= b->min_rtt_us || min_rtt_expired) {
		b->min_rtt_us = b->probe_rtt_min_us;
		b->min_rtt_stamp = b->probe_rtt_min_stamp;
	}

	if (probe_rtt_expired && !b->idle_restart &&
	    b->mode != BBR2_PROBE_RTT && b->min_rtt_us != BBR2_INF32) {
		/* Remember the window to restore after we drain the queue. */
		if (b->ca_state == BBR2_CA_OPEN)
			b->prior_cwnd = b->cwnd;
		else
			b->prior_cwnd = BBR2_MAX(b->prior_cwnd, b->cwnd);
		b->mode = BBR2_PROBE_RTT;
		b->probe_rtt_done_us = 0;
		b->probe_rtt_round_done = 0;
	}

	if (b->mode == BBR2_PROBE_RTT) {
		/* Keep samples taken now from being treated as bw limits. */
		b->app_limited = (b->delivered + a->inflight) ?
		    (b->delivered + a->inflight) : 1;
		if (!b->probe_rtt_done_us &&
		    a->inflight <= bbr2_probe_rtt_cwnd(b)) {
			b->probe_rtt_done_us = b->now_us +
			    b->p.probe_rtt_dur_ms * US_PER_MS;
			b->probe_rtt_round_done = 0;
			b->next_rtt_delivered = b->delivered;
		} else if (b->probe_rtt_done_us) {
			if (b->round_start)
				b->probe_rtt_round_done = 1;
			if (b->probe_rtt_round_done &&
			    b->now_us >= b->probe_rtt_done_us)
				exit_probe_rtt(b);
		}
	}
}

/* ------------------------------------------------------------------ */
/* cwnd                                                                */
/* ------------------------------------------------------------------ */

static uint32_t
bound_cwnd_for_inflight_model(const struct bbr2 *b, uint32_t cwnd)
{
	uint32_t cap;

	if (b->mode == BBR2_PROBE_RTT ||
	    (b->mode == BBR2_PROBE_BW && b->phase == BBR2_PHASE_CRUISE))
		cap = bbr2_inflight_with_headroom(b);
	else
		cap = b->inflight_hi;
	cap = BBR2_MIN(cap, b->inflight_lo);
	cap = BBR2_MAX(cap, bbr2_min_cwnd(b));
	return BBR2_MIN(cwnd, cap);
}

/* Packet conservation during recovery. Returns 1 if cwnd is final. */
static int
recover_or_restore(struct bbr2 *b, const struct bbr2_rs *rs,
    const struct bbr2_ack *a, int entered, int exited, uint32_t *cwnd)
{
	if (rs->lost > 0)
		*cwnd = *cwnd > rs->lost + b->mss ? *cwnd - rs->lost : b->mss;
	if (entered) {
		b->packet_conservation = 1;
		b->next_rtt_delivered = b->delivered;
		*cwnd = a->inflight + rs->acked;
	} else if (exited) {
		b->packet_conservation = 0;
		*cwnd = BBR2_MAX(*cwnd, b->prior_cwnd);
	}
	if (b->packet_conservation) {
		*cwnd = BBR2_MAX(*cwnd, a->inflight + rs->acked);
		return 1;
	}
	return 0;
}

static void
set_cwnd(struct bbr2 *b, const struct bbr2_rs *rs, const struct bbr2_ack *a,
    int entered, int exited)
{
	uint32_t cwnd = b->cwnd, target;
	uint64_t t;

	if (rs->acked == 0 && !entered && !exited)
		goto done;
	if (recover_or_restore(b, rs, a, entered, exited, &cwnd))
		goto done;

	t = (uint64_t)bbr2_inflight_at(b, bbr2_cur_bw(b), b->cwnd_gain) +
	    aggr_cwnd(b);
	target = t > BBR2_INF32 - 1 ? BBR2_INF32 - 1 : (uint32_t)t;

	if (b->full_bw_reached)
		cwnd = BBR2_MIN(cwnd + rs->acked, target);
	else if (cwnd < target ||
	    b->delivered < (uint64_t)b->p.init_cwnd_segs * b->mss)
		cwnd += rs->acked;
	cwnd = BBR2_MAX(cwnd, bbr2_min_cwnd(b));
done:
	cwnd = bound_cwnd_for_inflight_model(b, cwnd);
	if (b->mode == BBR2_PROBE_RTT)
		cwnd = BBR2_MIN(cwnd, bbr2_probe_rtt_cwnd(b));
	b->cwnd = cwnd;
}

/* ------------------------------------------------------------------ */
/* Entry points                                                        */
/* ------------------------------------------------------------------ */

void
bbr2_on_ack(struct bbr2 *b, const struct bbr2_ack *a)
{
	struct bbr2_rs rs;
	int entered = 0, exited = 0;

	b->now_us = a->now_us;
	bbr2_rate_cum_ack(b, a->ack_seq);
	bbr2_rate_gen(b, a, &rs);

	if (a->ca_state != b->ca_state) {
		if (b->ca_state == BBR2_CA_OPEN) {
			entered = 1;
			b->prior_cwnd = b->cwnd;
		} else if (a->ca_state == BBR2_CA_OPEN) {
			exited = 1;
		}
		b->prev_ca_state = b->ca_state;
		b->ca_state = a->ca_state;
	}

	if (a->rtt_us > 0)
		b->last_rtt_us = (uint32_t)BBR2_MIN((uint64_t)a->rtt_us, BBR2_INF32 - 1);
	if (!b->has_seen_rtt && a->rtt_us > 0)
		bbr2_init_pacing_rate_from_rtt(b, (uint64_t)a->rtt_us);

	update_round(b, &rs);
	update_bw(b, &rs);
	update_ack_aggregation(b, &rs);
	update_signals(b, &rs);
	adapt_upper_bounds(b, &rs, a);
	update_mode(b, &rs, a);
	update_min_rtt(b, a);
	bbr2_update_gains(b);
	bbr2_set_pacing_rate(b, bbr2_cur_bw(b), b->pacing_gain);
	set_cwnd(b, &rs, a, entered, exited);

	if (a->acked_bytes)
		b->idle_restart = 0;
}

void
bbr2_on_loss(struct bbr2 *b, uint32_t lost_bytes)
{
	b->pending_lost += lost_bytes;
}

/* Retransmission timeout: the stack has typically collapsed cwnd to 1 MSS. */
void
bbr2_on_rto(struct bbr2 *b, uint32_t inflight, uint64_t now_us)
{
	(void)inflight;
	b->now_us = now_us;
	if (b->ca_state == BBR2_CA_OPEN)
		b->prior_cwnd = b->cwnd;
	else
		b->prior_cwnd = BBR2_MAX(b->prior_cwnd, b->cwnd);
	/* inflight_lo needs the window from before the RTO. */
	if (!bbr2_is_probing_bw(b) && b->inflight_lo == BBR2_INF32)
		b->inflight_lo = b->cwnd;
	b->prev_ca_state = b->ca_state;
	b->ca_state = BBR2_CA_LOSS;
	b->packet_conservation = 1;
	b->next_rtt_delivered = b->delivered;
	b->lost_in_round += b->mss;
	b->loss_events_in_round++;
	b->full_bw = 0;			/* re-learn bandwidth after RTO */
	b->full_bw_cnt = 0;
	b->cwnd = b->mss;
}

void
bbr2_set_app_limited(struct bbr2 *b, uint32_t inflight)
{
	if (inflight >= b->cwnd)
		return;
	b->app_limited = (b->delivered + inflight) ?
	    (b->delivered + inflight) : 1;
}
