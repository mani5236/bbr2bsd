/*
 * glue_test.c - exercises the stack-facing API (adapter/tcp_bbr2_glue.h) the
 * way a TCP stack would: fill a bbr2_tp_view per event, apply bbr2_out.
 * Includes an RTO injected mid-run to verify recovery.
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#include <stdio.h>
#include <stdlib.h>
#include "tcp_bbr2_glue.h"

#define MSS 1448u
#define N   (1 << 16)

static int fails;
static void check(int ok, const char *what, double v)
{
	printf("  [%s] %-52s (%.3f)\n", ok ? "PASS" : "FAIL", what, v);
	fails += !ok;
}

int main(void)
{
	const double link_Bps = 50e6 / 8;	/* 50 Mbps */
	const uint64_t prop_us = 20000;		/* 20 ms */
	static uint64_t ack_at[N]; static uint32_t ack_seq_end[N], ack_sent_idx[N];
	static uint64_t sent_at[N];
	struct bbr2_conn c; struct bbr2_out o;
	uint64_t now = 0, next_pace = 0, link_free = 0, ser = (uint64_t)(MSS / link_Bps * 1e6);
	uint32_t head = 0, tail = 0, seq = 0, una = 0, inflight = 0;
	int rto_done = 0; uint64_t rto_at = 12000000, end = 25000000;
	double cwnd_after_rto = 1e18; int reported = 0;
	double bdp = link_Bps * prop_us / 1e6;

	bbr2c_init(&c, MSS, 0, 42, &o);
	printf("glue_test: 50 Mbps, 20 ms, RTO injected at 12 s\n");
	while (now < end) {
		uint64_t t_ack = head != tail ? ack_at[head % N] : ~0ULL;
		uint64_t t_snd = (inflight + MSS <= o.cwnd) ? (next_pace > now ? next_pace : now) : ~0ULL;
		if (!rto_done && now >= rto_at) {
			struct bbr2_tp_view v = { now, una, seq, inflight, MSS, 0, -1, 0, 0, 0 };
			/* A timeout: the stack presumes the whole flight lost. */
			bbr2c_on_rto(&c, &v, &o);
			rto_done = 1; cwnd_after_rto = o.cwnd;
		}
		if (t_ack <= t_snd) {
			struct bbr2_tp_view v;
			if (t_ack == ~0ULL) break;
			now = t_ack;
			una = ack_seq_end[head % N];
			inflight -= MSS;
			v = (struct bbr2_tp_view){ now, una, seq, inflight, MSS, 0,
			    (int64_t)(now - sent_at[ack_sent_idx[head % N] % N]), MSS, 0, 0 };
			head++;
			bbr2c_on_ack(&c, &v, &o);
		} else {
			uint64_t dep;
			now = t_snd;
			bbr2c_on_output(&c, seq, MSS, inflight, 0, now);
			sent_at[tail % N] = now;
			dep = (link_free > now ? link_free : now) + ser;
			link_free = dep;
			ack_at[tail % N] = dep + prop_us;
			ack_seq_end[tail % N] = seq + MSS;
			ack_sent_idx[tail % N] = tail;
			tail++; seq += MSS; inflight += MSS;
			next_pace = now + bbr2c_pacing_gap_us(&c, MSS);
		}
		if (!reported && now > 10000000) {
			reported = 1;
			struct bbr2_info in; bbr2_get_info(&c.core, &in);
			printf("  t=10s mode=%s bw=%.1f Mbps pace=%.1f Mbps cwnd=%.2f BDP minrtt=%.1f ms\n",
			    bbr2_mode_name(&c.core), in.bw * 8 / 1e6, in.pacing_rate * 8 / 1e6,
			    in.cwnd / bdp, in.min_rtt_us / 1e3);
			check(in.bw * 8 / 1e6 > 44 && in.bw * 8 / 1e6 < 55, "bw estimate within 12% of link", in.bw * 8 / 1e6);
			check(in.cwnd > bdp && in.cwnd < 4 * bdp, "cwnd between 1 and 4 BDP", in.cwnd / bdp);
			check(in.min_rtt_us > 19000 && in.min_rtt_us < 24000, "min RTT ~ propagation delay", in.min_rtt_us / 1e3);
			check(o.ssthresh == o.cwnd, "ssthresh pinned to cwnd", o.ssthresh);
			check(o.quantum >= 2 * MSS, "send quantum >= 2 MSS", o.quantum);
		}
	}
	{
		struct bbr2_info in; bbr2_get_info(&c.core, &in);
		printf("  end: mode=%s bw=%.1f Mbps cwnd=%.2f BDP\n", bbr2_mode_name(&c.core),
		    in.bw * 8 / 1e6, in.cwnd / bdp);
		check(rto_done, "RTO path exercised", rto_done);
		check(cwnd_after_rto <= 4 * MSS, "cwnd collapsed immediately after RTO (MSS)", cwnd_after_rto / MSS);
		check(in.cwnd > 0.9 * bdp, "cwnd recovered to >= 0.9 BDP after RTO", in.cwnd / bdp);
		check(in.bw * 8 / 1e6 > 40, "bandwidth estimate recovered", in.bw * 8 / 1e6);
	}
	printf("%s\n", fails ? "GLUE TEST FAILED" : "GLUE TEST PASSED");
	return fails ? 1 : 0;
}
