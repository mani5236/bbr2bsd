/*
 * sim.c - discrete-event bottleneck simulator + regression suite for bbr2.
 *
 * Topology: N senders -> one FIFO drop-tail bottleneck (rate, buffer) ->
 *           propagation delay -> ACK back.  Each sender runs a private
 *           struct bbr2 and is driven through exactly the same API a real
 *           TCP stack would use (bbr2_on_send / on_sack / on_ack / on_rto).
 *
 *   ./sim --suite                       run all regression scenarios
 *   ./sim BW_MBPS RTT_MS BUF_PCT LOSS_PPM FLOWS SECS [-v]
 *         BUF_PCT = buffer as percent of BDP, LOSS_PPM = random loss/million
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "bbr2.h"

#define MSS		1448u
#define MAXFLOWS	4
#define QCAP		(1u << 16)

struct pkt {
	uint64_t last_sent;
	uint8_t acked, lost, inflight, retx;
};

struct flow {
	struct bbr2 b;
	struct pkt *pk;
	uint32_t maxpk, next_new, una;
	uint32_t *rq; uint32_t rq_h, rq_t;	/* retransmit queue */
	uint64_t inflight_bytes;
	uint64_t next_send_us;
	int send_scheduled;
	int ca_state;
	uint32_t recovery_idx;
	uint64_t last_ack_us;
	/* stats */
	uint64_t delivered_meas, sent_pkts, retx_pkts;
	double rtt_sum; uint64_t rtt_n;
};

struct ev { uint64_t t; int type, flow; uint32_t idx; uint64_t tx_sent; };
enum { EV_SEND, EV_DEPART, EV_ACK, EV_TRACE };

struct qent { int flow; uint32_t idx; uint64_t tx_sent; };

struct scen {
	const char *name;
	double bw_mbps, rtt_ms, buf_pct;
	uint32_t loss_ppm;
	int flows;
	double secs;
	int verbose;
	double stagger_s;		/* flow k starts at k*stagger */
};

struct result {
	double goodput_mbps[MAXFLOWS];
	double total_mbps, util, avg_rtt_ms, loss_pct, jain;
	double avg_queue_bdp;
	int final_mode[MAXFLOWS];
	uint32_t inflight_hi[MAXFLOWS];
};

/* ---- event heap ---- */
static struct ev *heap; static size_t hn, hcap;
static void hpush(struct ev e)
{
	size_t i;
	if (hn == hcap) { hcap = hcap ? hcap * 2 : 4096; heap = realloc(heap, hcap * sizeof *heap); }
	i = hn++;
	while (i && heap[(i - 1) / 2].t > e.t) { heap[i] = heap[(i - 1) / 2]; i = (i - 1) / 2; }
	heap[i] = e;
}
static struct ev hpop(void)
{
	struct ev top = heap[0], last = heap[--hn];
	size_t i = 0;
	for (;;) {
		size_t c = 2 * i + 1;
		if (c >= hn) break;
		if (c + 1 < hn && heap[c + 1].t < heap[c].t) c++;
		if (heap[c].t >= last.t) break;
		heap[i] = heap[c]; i = c;
	}
	if (hn) heap[i] = last;
	return top;
}

/* ---- sim state ---- */
static struct scen S;
static struct flow F[MAXFLOWS];
static struct qent *Q; static uint32_t qh, qt; static uint64_t qbytes, qcap_bytes;
static int link_busy;
static uint64_t now, rtt_prop_us, warm_us, end_us;
static uint32_t rng = 88172645u;
static double qsum; static uint64_t qn;
static double bw_Bps;

static uint32_t rnd(void) { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng; }
static uint64_t ser_us(void) { return (uint64_t)(MSS * 1e6 / bw_Bps + 0.5); }

static void sched_send(int fi, uint64_t t)
{
	struct ev e = { t, EV_SEND, fi, 0, 0 };
	if (F[fi].send_scheduled) return;
	F[fi].send_scheduled = 1;
	hpush(e);
}

static void enqueue(int fi, uint32_t idx)
{
	if (qbytes + MSS > qcap_bytes || (S.loss_ppm && rnd() % 1000000 < S.loss_ppm))
		return;				/* dropped */
	Q[qt++ & (QCAP - 1)] = (struct qent){ fi, idx, F[fi].pk[idx].last_sent };
	qbytes += MSS;
	if (!link_busy) {
		struct ev e = { now + ser_us(), EV_DEPART, 0, 0, 0 };
		link_busy = 1; hpush(e);
	}
}

static void try_send(int fi)
{
	struct flow *f = &F[fi];

	for (;;) {
		uint32_t idx; int retx = 0; uint64_t rate;
		if (now < f->next_send_us) { sched_send(fi, f->next_send_us); return; }
		if (f->inflight_bytes >= bbr2_get_cwnd(&f->b)) return;
		while (f->rq_h != f->rq_t && f->pk[f->rq[f->rq_h & (f->maxpk - 1)]].acked) f->rq_h++;
		if (f->rq_h != f->rq_t) { idx = f->rq[f->rq_h++ & (f->maxpk - 1)]; retx = 1; }
		else if (f->next_new < f->maxpk) idx = f->next_new++;
		else return;
		bbr2_on_send(&f->b, idx * MSS, MSS, (uint32_t)f->inflight_bytes, retx, now);
		f->pk[idx].last_sent = now; f->pk[idx].lost = 0;
		f->pk[idx].inflight = 1; f->pk[idx].retx |= retx;
		f->inflight_bytes += MSS; f->sent_pkts++; f->retx_pkts += retx;
		enqueue(fi, idx);
		rate = bbr2_get_pacing_rate(&f->b);
		f->next_send_us = rate ? now + (uint64_t)(MSS * 1e6 / (double)rate) : now;
	}
}

static void rto_check(int fi)
{
	struct flow *f = &F[fi];
	uint32_t i;
	if (f->inflight_bytes == 0 || now - f->last_ack_us < 1000000) return;
	for (i = f->una; i < f->next_new; i++)
		if (!f->pk[i].acked && f->pk[i].inflight) {
			f->pk[i].inflight = 0; f->pk[i].lost = 1;
			f->rq[f->rq_t++ & (f->maxpk - 1)] = i;
			f->inflight_bytes -= MSS;
		}
	f->ca_state = BBR2_CA_LOSS; f->recovery_idx = f->next_new;
	f->last_ack_us = now;
	bbr2_on_rto(&f->b, 0, now);
}

static void on_ack_event(struct ev *e)
{
	struct flow *f = &F[e->flow];
	struct bbr2_ack a;
	struct pkt *p = &f->pk[e->idx];
	uint32_t i, nlost = 0, oldun = f->una; (void)oldun;
	uint32_t acked = 0;

	f->last_ack_us = now;
	if (!p->acked) {
		p->acked = 1;
		if (p->inflight) { p->inflight = 0; f->inflight_bytes -= MSS; }
		acked = MSS;
		bbr2_on_sack(&f->b, e->idx * MSS, e->idx * MSS + MSS);
		if (now >= warm_us) f->delivered_meas += MSS;
	}
	/* loss detection: anything sent before the acked tx and still unacked */
	for (i = f->una; i < e->idx; i++) {
		struct pkt *q = &f->pk[i];
		if (!q->acked && !q->lost && q->inflight && q->last_sent < e->tx_sent) {
			q->lost = 1; q->inflight = 0; f->inflight_bytes -= MSS;
			f->rq[f->rq_t++ & (f->maxpk - 1)] = i; nlost++;
		}
	}
	while (f->una < f->next_new && f->pk[f->una].acked) f->una++;
	if (nlost && f->ca_state == BBR2_CA_OPEN) {
		f->ca_state = BBR2_CA_RECOVERY; f->recovery_idx = f->next_new;
	}
	if (f->ca_state != BBR2_CA_OPEN && f->una >= f->recovery_idx && f->rq_h == f->rq_t)
		f->ca_state = BBR2_CA_OPEN;

	a.now_us = now; a.ack_seq = f->una * MSS; a.acked_bytes = acked;
	a.lost_bytes = nlost * MSS; a.ce_bytes = 0;
	a.rtt_us = (int64_t)(now - e->tx_sent);
	a.inflight = (uint32_t)f->inflight_bytes; a.ca_state = f->ca_state;
	bbr2_on_ack(&f->b, &a);
	if (now >= warm_us && acked) { f->rtt_sum += (double)a.rtt_us; f->rtt_n++; }
	try_send(e->flow);
}

static void print_trace(void)
{
	int k;
	for (k = 0; k < S.flows; k++) {
		struct bbr2_info in; bbr2_get_info(&F[k].b, &in);
		printf("t=%6.2fs f%d %-16s cwnd=%7u pace=%7.2fMbps bw=%7.2fMbps minrtt=%6.1fms "
		    "inflt=%7llu hi=%s q=%5.0fKB\n", now / 1e6, k, bbr2_mode_name(&F[k].b),
		    in.cwnd, in.pacing_rate * 8 / 1e6, in.bw * 8 / 1e6,
		    in.min_rtt_us == BBR2_INF32 ? -1.0 : in.min_rtt_us / 1e3,
		    (unsigned long long)F[k].inflight_bytes,
		    in.inflight_hi == BBR2_INF32 ? "inf" : "set", qbytes / 1024.0);
	}
}

static void run(const struct scen *sc, struct result *r)
{
	int k; double tot = 0, sq = 0, rs = 0; uint64_t rn = 0, sent = 0, retx = 0;
	double bdp;

	S = *sc; hn = 0; qh = qt = 0; qbytes = 0; link_busy = 0; now = 0; qsum = 0; qn = 0; rng = 88172645u;
	bw_Bps = S.bw_mbps * 1e6 / 8;
	rtt_prop_us = (uint64_t)(S.rtt_ms * 1000);
	bdp = bw_Bps * S.rtt_ms / 1000;
	qcap_bytes = (uint64_t)(bdp * S.buf_pct / 100.0);
	if (qcap_bytes < 4 * MSS) qcap_bytes = 4 * MSS;
	end_us = (uint64_t)(S.secs * 1e6); warm_us = end_us / 3;
	if (!Q) Q = malloc(QCAP * sizeof *Q);
	for (k = 0; k < S.flows; k++) {
		struct flow *f = &F[k];
		free(f->pk); free(f->rq);
		memset(f, 0, sizeof *f);
		f->maxpk = 1u << 22;		/* ~6 GB of data per flow */
		f->pk = calloc(f->maxpk, sizeof *f->pk);
		f->rq = calloc(f->maxpk, sizeof *f->rq);
		{
			struct bbr2_params pp; const char *e;
			bbr2_params_default(&pp);
#define ENVP(name) if ((e = getenv("P_" #name))) pp.name = (uint32_t)atoi(e)
			ENVP(headroom_pct); ENVP(beta); ENVP(loss_thresh_ppt); ENVP(cwnd_gain);
			ENVP(probe_wait_base_ms); ENVP(probe_wait_rand_ms); ENVP(extra_acked_gain);
			ENVP(probe_up_gain); ENVP(probe_down_gain); ENVP(startup_cwnd_gain);
			ENVP(probe_reno_gain); ENVP(probe_rtt_win_ms);
#undef ENVP
			bbr2_init(&f->b, &pp, MSS, (uint64_t)(k * S.stagger_s * 1e6), 1234567u + (uint32_t)k * 7919);
		}
		f->next_send_us = (uint64_t)(k * S.stagger_s * 1e6);
		sched_send(k, f->next_send_us);
	}
	{ struct ev e = { 500000, EV_TRACE, 0, 0, 0 }; hpush(e); }

	while (hn) {
		struct ev e = hpop();
		if (e.t > end_us) break;
		now = e.t;
		if (now >= warm_us) { qsum += (double)qbytes; qn++; }
		switch (e.type) {
		case EV_SEND:
			F[e.flow].send_scheduled = 0; rto_check(e.flow); try_send(e.flow); break;
		case EV_DEPART: {
			struct qent q = Q[qh++ & (QCAP - 1)];
			struct ev a = { now + rtt_prop_us, EV_ACK, q.flow, q.idx, q.tx_sent };
			qbytes -= MSS; hpush(a);
			if (qh != qt) { struct ev d = { now + ser_us(), EV_DEPART, 0, 0, 0 }; hpush(d); }
			else link_busy = 0;
			break; }
		case EV_ACK: on_ack_event(&e); break;
		case EV_TRACE:
			if (S.verbose) print_trace();
			e.t += 500000; hpush(e); break;
		}
	}
	for (k = 0; k < S.flows; k++) {
		struct bbr2_info in; struct flow *f = &F[k];
		r->goodput_mbps[k] = f->delivered_meas * 8.0 / ((end_us - warm_us) / 1e6) / 1e6;
		tot += r->goodput_mbps[k]; sq += r->goodput_mbps[k] * r->goodput_mbps[k];
		rs += f->rtt_sum; rn += f->rtt_n; sent += f->sent_pkts; retx += f->retx_pkts;
		bbr2_get_info(&f->b, &in);
		r->final_mode[k] = in.mode; r->inflight_hi[k] = in.inflight_hi;
	}
	r->total_mbps = tot; r->util = tot / S.bw_mbps;
	r->avg_rtt_ms = rn ? rs / rn / 1e3 : 0;
	r->loss_pct = sent ? 100.0 * retx / sent : 0;
	r->jain = sq > 0 ? tot * tot / (S.flows * sq) : 0;
	r->avg_queue_bdp = qn ? qsum / qn / bdp : 0;
}

static int fails;
static void check(const char *scen, int ok, const char *what, double v)
{
	printf("    [%s] %-44s (%.3f)\n", ok ? "PASS" : "FAIL", what, v);
	if (!ok) { fails++; printf("      ^^ in scenario '%s'\n", scen); }
}

static void report(const struct scen *s, const struct result *r)
{
	int k;
	printf("\n== %s: %.0f Mbps, %.0f ms, buf %.0f%% BDP, loss %u ppm, %d flow(s), %.0fs\n",
	    s->name, s->bw_mbps, s->rtt_ms, s->buf_pct, s->loss_ppm, s->flows, s->secs);
	printf("   total %.2f Mbps (util %.1f%%)  avg RTT %.1f ms  retx %.2f%%  avg queue %.2f BDP  jain %.3f\n",
	    r->total_mbps, r->util * 100, r->avg_rtt_ms, r->loss_pct, r->avg_queue_bdp, r->jain);
	for (k = 0; k < s->flows; k++)
		printf("   flow%d: %.2f Mbps  final mode %d  inflight_hi %s\n", k, r->goodput_mbps[k],
		    r->final_mode[k], r->inflight_hi[k] == BBR2_INF32 ? "unset" : "set");
}

static void suite(void)
{
	struct scen s; struct result r;

	s = (struct scen){ "clean path, 2xBDP buffer", 100, 40, 200, 0, 1, 30, 0, 0 };
	run(&s, &r); report(&s, &r);
	check(s.name, r.util > 0.90, "utilisation > 90%", r.util);
	check(s.name, r.avg_queue_bdp < 0.6, "standing queue < 0.6 BDP", r.avg_queue_bdp);
	check(s.name, r.loss_pct < 1.0, "retransmissions < 1%", r.loss_pct);
	check(s.name, r.final_mode[0] == BBR2_PROBE_BW || r.final_mode[0] == BBR2_PROBE_RTT, "reached steady state", r.final_mode[0]);

	s = (struct scen){ "1% random loss", 100, 40, 200, 10000, 1, 30, 0, 0 };
	run(&s, &r); report(&s, &r);
	check(s.name, r.util > 0.80, "utilisation > 80% under 1% loss", r.util);

	s = (struct scen){ "shallow buffer (0.25 BDP)", 100, 40, 25, 0, 1, 30, 0, 0 };
	run(&s, &r); report(&s, &r);
	check(s.name, r.util > 0.70, "utilisation > 70% with shallow buffer", r.util);
	check(s.name, r.loss_pct < 10.0, "retx < 10% (loss bounded by inflight_hi)", r.loss_pct);

	s = (struct scen){ "two flows share fairly", 100, 40, 100, 0, 2, 60, 0, 2.0 };
	run(&s, &r); report(&s, &r);
	check(s.name, r.util > 0.85, "aggregate utilisation > 85%", r.util);
	check(s.name, r.jain > 0.85, "Jain fairness index > 0.85", r.jain);

	s = (struct scen){ "high BDP (1Gbps, 100ms)", 1000, 100, 100, 0, 1, 30, 0, 0 };
	run(&s, &r); report(&s, &r);
	check(s.name, r.util > 0.85, "utilisation > 85% on long fat pipe", r.util);

	printf("\n%s (%d failed check%s)\n", fails ? "SUITE FAILED" : "SUITE PASSED", fails, fails == 1 ? "" : "s");
}

int main(int argc, char **argv)
{
	if (argc >= 2 && !strcmp(argv[1], "--suite")) { suite(); return fails ? 1 : 0; }
	if (argc >= 7) {
		struct scen s = { "custom", atof(argv[1]), atof(argv[2]), atof(argv[3]),
		    (uint32_t)atoi(argv[4]), atoi(argv[5]), atof(argv[6]), 0, 0 };
		struct result r;
		if (s.flows < 1 || s.flows > MAXFLOWS) return 2;
		s.verbose = argc > 7 && !strcmp(argv[7], "-v");
		if (s.flows > 1) s.stagger_s = 2.0;
		run(&s, &r); report(&s, &r); return 0;
	}
	fprintf(stderr, "usage: %s --suite | BW_MBPS RTT_MS BUF_PCT LOSS_PPM FLOWS SECS [-v]\n", argv[0]);
	return 2;
}
