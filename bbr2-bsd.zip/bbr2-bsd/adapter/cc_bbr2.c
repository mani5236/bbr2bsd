/*
 * cc_bbr2.c - FreeBSD cc(9) congestion-control module wrapping the BBRv2 core.
 *
 * TARGET: FreeBSD 14.x (uses the cc_data_sz / rttsample hooks).  The cc(9)
 * KPI changes between releases; verify the struct cc_algo layout in YOUR
 * <netinet/cc/cc.h> before building.  This file cannot be compiled outside a
 * FreeBSD source tree; everything it delegates to (tcp_bbr2_glue.c and the
 * core) is compiled and tested in userland - see test/.
 *
 * cc(9) has no "segment transmitted" upcall and no pacing support, both of
 * which BBR needs.  Two small hooks in the stack provide them; see
 * docs/INTEGRATION.md section 3 ("tcp_output.c patch").  Without them the
 * module still loads and runs, degraded to ack-clocked, unpaced operation
 * with no delivery-rate samples (NOT recommended for production).
 *
 * Build:  cd adapter && make            (bsd.kmod.mk)
 * Load:   kldload ./cc_bbr2.ko
 * Use:    sysctl net.inet.tcp.cc.algorithm=bbr2
 *         or per socket: setsockopt(TCP_CONGESTION, "bbr2")
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#include <sys/cdefs.h>
#include <sys/param.h>
#include <sys/kernel.h>
#include <sys/malloc.h>
#include <sys/module.h>
#include <sys/socket.h>
#include <sys/socketvar.h>
#include <sys/sysctl.h>
#include <sys/systm.h>
#include <sys/time.h>

#include <net/vnet.h>

#include <netinet/in.h>
#include <netinet/in_pcb.h>
#include <netinet/tcp.h>
#include <netinet/tcp_seq.h>
#include <netinet/tcp_var.h>
#include <netinet/cc/cc.h>
#include <netinet/cc/cc_module.h>

#include "tcp_bbr2_glue.h"

static MALLOC_DEFINE(M_BBR2, "bbr2", "TCP BBRv2 congestion control state");

/* Per-connection state stored in ccv->cc_data. */
struct cc_bbr2 {
	struct bbr2_conn conn;
	uint32_t prev_sacked;		/* sackhint.sacked_bytes at last ACK */
	int64_t  pending_rtt_us;	/* from rttsample(), consumed by next ACK */
	int      ecn_pending;
	int      app_limited_seen;
};

static inline uint64_t
bbr2_now_us(void)
{
	return (uint64_t)(sbinuptime() / SBT_1US);
}

/* Apply the core's decision to the TCP control block. */
static void
bbr2_apply(struct cc_var *ccv, const struct bbr2_out *o)
{
	struct tcpcb *tp = ccv->ccvc.tcp;

	tp->snd_cwnd = o->cwnd;
	tp->snd_ssthresh = o->ssthresh;
	/*
	 * Pacing: publish the rate for the stack's pacer (see INTEGRATION.md).
	 * If your tcpcb carries a pacing-rate field (RACK/BBR stacks use
	 * t_pacing_rate), assign it here:
	 *     tp->t_pacing_rate = o->pacing_rate;
	 */
#ifdef BBR2_HAVE_TCPCB_PACING
	tp->t_pacing_rate = o->pacing_rate;
#endif
}

static size_t
bbr2_cc_data_sz(void)
{
	return (sizeof(struct cc_bbr2));
}

static int
bbr2_cb_init(struct cc_var *ccv, void *ptr)
{
	struct cc_bbr2 *b;

	if (ptr == NULL) {
		b = malloc(sizeof(*b), M_BBR2, M_NOWAIT | M_ZERO);
		if (b == NULL)
			return (ENOMEM);
	} else {
		b = ptr;
		memset(b, 0, sizeof(*b));
	}
	ccv->cc_data = b;
	return (0);
}

static void
bbr2_cb_destroy(struct cc_var *ccv)
{
	/* With cc_data_sz() the framework owns the memory; nothing to free. */
}

static void
bbr2_conn_init(struct cc_var *ccv)
{
	struct cc_bbr2 *b = ccv->cc_data;
	struct tcpcb *tp = ccv->ccvc.tcp;
	struct bbr2_out o;

	bbr2c_init(&b->conn, tp->t_maxseg, bbr2_now_us(), arc4random(), &o);
	b->pending_rtt_us = -1;
	b->prev_sacked = 0;
	bbr2_apply(ccv, &o);
}

/* FreeBSD 14: exact per-ACK RTT sample. */
static void
bbr2_rttsample(struct cc_var *ccv, uint32_t usec_rtt, uint32_t rxtcnt,
    uint32_t fas)
{
	struct cc_bbr2 *b = ccv->cc_data;

	if (rxtcnt == 0)		/* Karn: ignore RTT of retransmits */
		b->pending_rtt_us = usec_rtt;
}

static uint32_t
bbr2_inflight(struct tcpcb *tp)
{
	if ((tp->t_flags & TF_SACK_PERMIT) != 0)
		return (uint32_t)tcp_compute_pipe(tp);
	return (uint32_t)(tp->snd_max - tp->snd_una);
}

static void
bbr2_fill_view(struct cc_var *ccv, struct cc_bbr2 *b, struct bbr2_tp_view *v)
{
	struct tcpcb *tp = ccv->ccvc.tcp;
	int32_t sacked_now, sack_delta, newly;

	memset(v, 0, sizeof(*v));
	v->now_us = bbr2_now_us();
	v->snd_una = tp->snd_una;
	v->snd_max = tp->snd_max;
	v->mss = tp->t_maxseg;
	v->inflight = bbr2_inflight(tp);
	v->in_recovery = IN_RECOVERY(tp->t_flags) ? 1 : 0;
	v->rtt_us = b->pending_rtt_us;
	b->pending_rtt_us = -1;

	/*
	 * Newly delivered = bytes cumulatively acked + change in SACKed bytes.
	 * When the cumulative ACK sweeps over bytes that were SACKed earlier,
	 * the sack delta is negative by exactly that amount, which cancels the
	 * double count inside bytes_this_ack.
	 */
	sacked_now = (tp->t_flags & TF_SACK_PERMIT) ?
	    (int32_t)tp->sackhint.sacked_bytes : 0;
	sack_delta = sacked_now - (int32_t)b->prev_sacked;
	b->prev_sacked = (uint32_t)sacked_now;
	newly = (int32_t)ccv->bytes_this_ack + sack_delta;
	v->bytes_acked = newly > 0 ? (uint32_t)newly : 0;

	if (b->ecn_pending) {
		/* RFC 3168 gives one bit per RTT-ish; attribute this ACK's data. */
		v->bytes_ce = v->bytes_acked;
		b->ecn_pending = 0;
	}
}

static void
bbr2_ack_received(struct cc_var *ccv, uint16_t type)
{
	struct cc_bbr2 *b = ccv->cc_data;
	struct bbr2_tp_view v;
	struct bbr2_out o;

	bbr2_fill_view(ccv, b, &v);
	/* v.bytes_lost: take the stack's lost-bytes delta here if it keeps one
	 * (e.g. tp->sackhint.hole_bytes growth, or RACK lost counters). */
	bbr2c_on_ack(&b->conn, &v, &o);
	bbr2_apply(ccv, &o);
}

static void
bbr2_cong_signal(struct cc_var *ccv, uint32_t type)
{
	struct cc_bbr2 *b = ccv->cc_data;
	struct tcpcb *tp = ccv->ccvc.tcp;
	struct bbr2_tp_view v;
	struct bbr2_out o;

	switch (type) {
	case CC_NDUPACK:
		/* Entering fast recovery: BBR decides the window, not the stack. */
		tp->snd_ssthresh = tp->snd_cwnd;
		break;
	case CC_ECN:
		b->ecn_pending = 1;
		tp->snd_ssthresh = tp->snd_cwnd;
		break;
	case CC_RTO:
		bbr2_fill_view(ccv, b, &v);
		bbr2c_on_rto(&b->conn, &v, &o);
		bbr2_apply(ccv, &o);
		break;
	case CC_RTO_ERR:
		/* Spurious timeout: the next ACK restores prior_cwnd via the
		 * core's LOSS -> OPEN transition. */
		break;
	default:
		break;
	}
}

static void
bbr2_post_recovery(struct cc_var *ccv)
{
	struct cc_bbr2 *b = ccv->cc_data;
	struct tcpcb *tp = ccv->ccvc.tcp;

	/* The stack deflates cwnd to ssthresh here; hand it BBR's value. */
	tp->snd_cwnd = bbr2_get_cwnd(&b->conn.core);
}

static void
bbr2_after_idle(struct cc_var *ccv)
{
	/* Do NOT collapse to the initial window like NewReno: BBR resumes at
	 * its model's rate (the core detects the idle restart in on_output). */
}

static int
bbr2_mod_init(void)
{
	/* Publish the transmit hook so tcp_output() can feed the sampler. */
	return (0);
}

struct cc_algo bbr2_cc_algo = {
	.name = "bbr2",
	.mod_init = bbr2_mod_init,
	.cc_data_sz = bbr2_cc_data_sz,
	.cb_init = bbr2_cb_init,
	.cb_destroy = bbr2_cb_destroy,
	.conn_init = bbr2_conn_init,
	.ack_received = bbr2_ack_received,
	.cong_signal = bbr2_cong_signal,
	.post_recovery = bbr2_post_recovery,
	.after_idle = bbr2_after_idle,
	.rttsample = bbr2_rttsample,
};

/*
 * Transmit hook, called from tcp_output() after a segment/TSO burst has been
 * passed to ip_output() successfully.  Install via tcp_cc_output_hook (see
 * docs/INTEGRATION.md).  'rexmit' is non-zero for retransmissions.
 */
void
bbr2_cc_output_hook(struct tcpcb *tp, tcp_seq seq, int len, int rexmit)
{
	struct cc_bbr2 *b;

	if (CC_ALGO(tp) != &bbr2_cc_algo)
		return;
	b = tp->t_ccv.cc_data;
	bbr2c_on_output(&b->conn, seq, (uint32_t)len,
	    bbr2_inflight(tp) - (uint32_t)len, rexmit, bbr2_now_us());
}

/* Pacing query for the stack's pacer: bytes/s and max burst size. */
uint64_t
bbr2_cc_pacing_rate(struct tcpcb *tp, uint32_t *quantum)
{
	struct cc_bbr2 *b = tp->t_ccv.cc_data;

	if (CC_ALGO(tp) != &bbr2_cc_algo)
		return (0);
	if (quantum != NULL)
		*quantum = bbr2_get_send_quantum(&b->conn.core);
	return (bbr2_get_pacing_rate(&b->conn.core));
}

DECLARE_CC_MODULE(bbr2, &bbr2_cc_algo);
MODULE_VERSION(bbr2, 1);
