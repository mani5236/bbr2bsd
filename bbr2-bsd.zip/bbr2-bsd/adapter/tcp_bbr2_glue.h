/*
 * tcp_bbr2_glue.h - the seam between a BSD-derived TCP stack and the BBRv2
 * core.
 *
 * The core knows nothing about struct tcpcb.  This layer takes a plain
 * "view" of what the stack knows at an event (bbr2_tp_view) and returns what
 * the stack must apply (bbr2_out).  Everything stack-specific is therefore
 * confined to ~40 lines that fill the view (see cc_bbr2.c for FreeBSD's
 * cc(9) framework, and docs/INTEGRATION.md for a custom stack).
 *
 * This file is pure C and is unit-tested in userland (test/glue_test.c).
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#ifndef TCP_BBR2_GLUE_H
#define TCP_BBR2_GLUE_H

#include "bbr2.h"

/* What the stack knows when it calls us. Fill every field that applies. */
struct bbr2_tp_view {
	uint64_t now_us;	/* monotonic microseconds */
	uint32_t snd_una;	/* oldest unacknowledged sequence number */
	uint32_t snd_max;	/* highest sequence sent + 1 */
	uint32_t inflight;	/* bytes in flight (pipe), AFTER processing this event */
	uint32_t mss;		/* effective sender MSS */
	int      in_recovery;	/* stack is in fast/SACK recovery */
	int64_t  rtt_us;	/* RTT sample carried by this ACK, or -1 */
	uint32_t bytes_acked;	/* NEWLY cum-acked (not previously SACKed) + NEWLY SACKed */
	uint32_t bytes_lost;	/* bytes newly declared lost by the stack */
	uint32_t bytes_ce;	/* acked bytes carrying ECN-CE feedback */
};

/* What the stack must apply after the call. */
struct bbr2_out {
	uint32_t cwnd;		/* -> tp->snd_cwnd */
	uint32_t ssthresh;	/* -> tp->snd_ssthresh (== cwnd; stops the stack
				 *    from shrinking cwnd on its own) */
	uint64_t pacing_rate;	/* bytes/s -> the stack's pacer */
	uint32_t quantum;	/* max bytes per paced burst (TSO size cap) */
};

struct bbr2_conn {
	struct bbr2 core;
	int      loss_active;	/* between an RTO and snd_una reaching loss_until */
	uint32_t loss_until;
};

void bbr2c_init(struct bbr2_conn *c, uint32_t mss, uint64_t now_us,
    uint32_t seed, struct bbr2_out *out);

/* Transmit path: after each segment/TSO burst is handed to IP. */
void bbr2c_on_output(struct bbr2_conn *c, uint32_t seq, uint32_t len,
    uint32_t inflight_before, int is_rexmit, uint64_t now_us);

/* Input path: once per newly SACKed block (before bbr2c_on_ack). */
void bbr2c_on_sack(struct bbr2_conn *c, uint32_t start, uint32_t end);

/* Input path: exactly once per ACK segment, after the stack updated its own
 * snd_una / scoreboard / pipe. */
void bbr2c_on_ack(struct bbr2_conn *c, const struct bbr2_tp_view *v,
    struct bbr2_out *out);

/* Retransmission timer fired. */
void bbr2c_on_rto(struct bbr2_conn *c, const struct bbr2_tp_view *v,
    struct bbr2_out *out);

/* App ran out of data (call when send buffer empties and pipe < cwnd). */
void bbr2c_on_app_limited(struct bbr2_conn *c, uint32_t inflight);

/* Minimum spacing between paced bursts of 'len' bytes at the current rate. */
uint64_t bbr2c_pacing_gap_us(const struct bbr2_conn *c, uint32_t len);

#endif /* TCP_BBR2_GLUE_H */
