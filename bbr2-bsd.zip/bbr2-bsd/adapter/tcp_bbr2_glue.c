/*
 * tcp_bbr2_glue.c - see tcp_bbr2_glue.h.
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */
#include "tcp_bbr2_glue.h"

static inline int seq_lt(uint32_t a, uint32_t b) { return (int32_t)(a - b) < 0; }

static void
fill_out(const struct bbr2_conn *c, struct bbr2_out *out)
{
	out->cwnd = bbr2_get_cwnd(&c->core);
	out->ssthresh = out->cwnd;
	out->pacing_rate = bbr2_get_pacing_rate(&c->core);
	out->quantum = bbr2_get_send_quantum(&c->core);
}

void
bbr2c_init(struct bbr2_conn *c, uint32_t mss, uint64_t now_us, uint32_t seed,
    struct bbr2_out *out)
{
	BBR2_ZERO(c, sizeof(*c));
	bbr2_init(&c->core, NULL, mss, now_us, seed);
	if (out != NULL)
		fill_out(c, out);
}

void
bbr2c_on_output(struct bbr2_conn *c, uint32_t seq, uint32_t len,
    uint32_t inflight_before, int is_rexmit, uint64_t now_us)
{
	bbr2_on_send(&c->core, seq, len, inflight_before, is_rexmit, now_us);
}

void
bbr2c_on_sack(struct bbr2_conn *c, uint32_t start, uint32_t end)
{
	bbr2_on_sack(&c->core, start, end);
}

static int
derive_ca_state(struct bbr2_conn *c, const struct bbr2_tp_view *v)
{
	if (c->loss_active && !seq_lt(v->snd_una, c->loss_until))
		c->loss_active = 0;		/* everything sent before the RTO is acked */
	if (c->loss_active)
		return BBR2_CA_LOSS;
	return v->in_recovery ? BBR2_CA_RECOVERY : BBR2_CA_OPEN;
}

void
bbr2c_on_ack(struct bbr2_conn *c, const struct bbr2_tp_view *v,
    struct bbr2_out *out)
{
	struct bbr2_ack a;

	bbr2_set_mss(&c->core, v->mss);
	a.now_us = v->now_us;
	a.ack_seq = v->snd_una;
	a.acked_bytes = v->bytes_acked;
	a.lost_bytes = v->bytes_lost;
	a.ce_bytes = v->bytes_ce;
	a.rtt_us = v->rtt_us;
	a.inflight = v->inflight;
	a.ca_state = derive_ca_state(c, v);
	bbr2_on_ack(&c->core, &a);
	fill_out(c, out);
}

void
bbr2c_on_rto(struct bbr2_conn *c, const struct bbr2_tp_view *v,
    struct bbr2_out *out)
{
	c->loss_active = 1;
	c->loss_until = v->snd_max;
	bbr2_on_rto(&c->core, v->inflight, v->now_us);
	fill_out(c, out);
}

void
bbr2c_on_app_limited(struct bbr2_conn *c, uint32_t inflight)
{
	bbr2_set_app_limited(&c->core, inflight);
}

uint64_t
bbr2c_pacing_gap_us(const struct bbr2_conn *c, uint32_t len)
{
	uint64_t rate = bbr2_get_pacing_rate(&c->core);

	return rate ? (uint64_t)len * 1000000ULL / rate : 0;
}
